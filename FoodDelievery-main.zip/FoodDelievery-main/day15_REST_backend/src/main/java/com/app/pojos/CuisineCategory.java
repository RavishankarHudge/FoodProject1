package com.app.pojos;

public enum CuisineCategory {
	MAHARASHTRIAN,PUNJABI,RAJASTAHNI

}
