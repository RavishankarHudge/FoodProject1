package com.app.pojos;

public enum OrderStatus {
	OLD,NEW

}
