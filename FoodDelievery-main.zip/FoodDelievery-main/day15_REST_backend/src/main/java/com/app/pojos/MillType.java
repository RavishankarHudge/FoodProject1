package com.app.pojos;

public enum MillType {
ALL,BREAKFAST,LUNCH,DINNER
}
