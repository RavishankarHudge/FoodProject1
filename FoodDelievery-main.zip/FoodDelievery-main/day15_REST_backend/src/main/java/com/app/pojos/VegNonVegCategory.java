package com.app.pojos;

public enum VegNonVegCategory {
	VEG,NON_VEG

}
