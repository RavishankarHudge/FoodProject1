package com.app.service;

public interface FeedbackService {

	void addRatingAndDescription(Integer rating,String description,Long id);
}
