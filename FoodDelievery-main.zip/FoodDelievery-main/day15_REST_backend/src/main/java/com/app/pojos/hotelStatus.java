package com.app.pojos;

public enum hotelStatus {
     REJECTED,APPROVED
}
